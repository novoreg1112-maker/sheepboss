package com.example.sheepboss.client;

import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.SheepEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.passive.SheepEntity;

/** Vanilla sheep renderer, just 3x bigger. */
public class BossSheepRenderer extends SheepEntityRenderer {
    private static final float SCALE = 3.0F;

    public BossSheepRenderer(EntityRendererFactory.Context context) {
        super(context);
        this.shadowRadius = 0.7F * SCALE;
    }

    @Override
    protected void scale(SheepEntity entity, MatrixStack matrices, float amount) {
        matrices.scale(SCALE, SCALE, SCALE);
    }
}
